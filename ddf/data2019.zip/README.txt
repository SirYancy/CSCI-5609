In order to read these data files, you will need the Featherweight Interface Program.

https://www.featherweightaltimeters.com/interface-program.html